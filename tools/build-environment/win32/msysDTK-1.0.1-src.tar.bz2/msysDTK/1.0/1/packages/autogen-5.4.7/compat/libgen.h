/*
 *  %W%
 */
#ifndef LIBGEN_H
#define LIBGEN_H 1

#include "compat.h"
/* only include this *after* compat.h */

EXTERN char * basename  (/* char * */);

EXTERN char * dirname   (/* char * */);

EXTERN char * pathfind  (/* const char *, const char *, const char * */);

# endif /* LIBGEN_H */
