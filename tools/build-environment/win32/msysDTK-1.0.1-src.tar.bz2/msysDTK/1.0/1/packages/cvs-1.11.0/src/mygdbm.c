/*
 * 
 * You may distribute under the terms of the GNU General Public License as
 * specified in the README file that comes with the CVS source distribution.
 * 
 * A compatibility layer so that gdbm can be used to provide dbm services.
 * Now, gdbm does provide its own ndbm interface, but that one doesn't work
 * very well on Win9x cygwin.  gdbm's ndbm interface relies on hardlinking
 * foo.dir and foo.pag -- but hardlinks fail on Win9x.
 * 
 * This compatibility layer doesn't try to emulate the dir/pag filestructure
 * of ndbm; it merely wraps the ndbm calls around a "normal" gdbm database
 * and file access. 
 *
 * As it happens, we only need to override dbm_open to make this happen; we
 * can still use all of "ordinary" dbm emulation functions that gdbm 
 * provides. 
 * 
 */

#include "cvs.h"

#if defined(USE_GDBM) && !defined(MY_NDBM)

DBM *
my_gdbm_open (file, flags, mode)
    char *file;
    int flags;
    int mode;
{
    char* db_file;
    struct stat db_stat;
    GDBM_FILE db;
    DBM * ret_val;

    db_file = (char *) xmalloc (strlen (file)+4);
    strcpy (db_file, file);
    strcat (db_file, ".db");

    /* Call the actual routine, saving the pointer to the file information. */
    flags &= O_RDONLY | O_RDWR | O_CREAT | O_TRUNC;
    if (flags == O_RDONLY)
      {
        db = gdbm_open (db_file, 0, GDBM_READER, 00444, NULL);
      }
    else if (flags == (O_RDWR | O_CREAT))
      {
        db = gdbm_open (db_file, 0, GDBM_WRCREAT, mode, NULL);
      }
    else if ( (flags & O_TRUNC) == O_TRUNC)
      {
        db = gdbm_open (db_file, 0, GDBM_NEWDB, mode, NULL);
      }
    else
      {
        db = gdbm_open (db_file, 0, GDBM_WRITER, 00666, NULL);
      }

    ret_val = (DBM *) db;
    free (db_file);
    return (ret_val);
}

#endif				/* USE_GDBM && !MY_NDBM */
