#ifndef lint
/*static char yysccsid[] = "from: @(#)yaccpar	1.9 (Berkeley) 02/21/93";*/
static char yyrcsid[] = "$Id: skeleton.c,v 1.4 1993/12/21 18:45:32 jtc Exp $";
#endif
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING (yyerrflag!=0)
#define YYPREFIX "yy"
#line 2 "defParse.y"
/*
 *  $Id: defParse.y,v 1.15 2002/05/29 00:58:32 bkorb Exp $
 *  Parse rules for the macro definitions
 */

/*
 *  AutoGen copyright 1992-2002 Bruce Korb
 *
 *  AutoGen is free software.
 *  You may redistribute it and/or modify it under the terms of the
 *  GNU General Public License, as published by the Free Software
 *  Foundation; either version 2, or (at your option) any later version.
 *
 *  AutoGen is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with AutoGen.  See the file "COPYING".  If not,
 *  write to:  The Free Software Foundation, Inc.,
 *             59 Temple Place - Suite 330,
 *             Boston,  MA  02111-1307, USA.
 */


/*
 *  Declarations
 */
#include "autogen.h"

extern YYSTYPE addSibMacro( YYSTYPE, YYSTYPE );
extern YYSTYPE makeMacro( YYSTYPE, YYSTYPE, teValType );
extern YYSTYPE makeMacroList( YYSTYPE, YYSTYPE, teValType );
extern YYSTYPE startList( YYSTYPE );
extern YYSTYPE appendList( YYSTYPE, YYSTYPE );
extern YYSTYPE findPlace( YYSTYPE, YYSTYPE );
extern YYSTYPE identify( YYSTYPE );
extern YYSTYPE makeEmptyDefs( void );

extern int yyparse( void );

#line 56 "y.tab.c"
#define TK_AUTOGEN 257
#define TK_DEFINITIONS 258
#define TK_END 259
#define TK_VAR_NAME 260
#define TK_OTHER_NAME 261
#define TK_STRING 262
#define TK_NUMBER 263
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    0,    0,    2,    2,    2,    1,    3,    3,    3,    6,
    6,    7,    7,    9,    8,    8,    4,    4,    4,    5,
    5,    5,
};
short yylen[] = {                                         2,
    3,    2,    1,    2,    2,    4,    2,    4,    4,    1,
    3,    1,    3,    3,    1,    1,    1,    1,    1,    1,
    4,    4,
};
short yydefred[] = {                                      0,
    0,    0,    0,    0,    2,    0,    0,    0,    0,    0,
   19,   17,   18,    0,    0,    5,    1,    4,    7,    0,
    6,    0,    0,   16,    0,   15,    0,    0,    0,    0,
   22,   21,    0,    8,    9,    0,    0,   14,   11,   13,
};
short yydgoto[] = {                                       2,
    7,    8,    9,   26,   10,   27,   28,   29,   30,
};
short yysindex[] = {                                   -254,
 -243,    0, -248, -239,    0,  -72, -247, -234, -247,  -43,
    0,    0,    0,  -32, -246,    0,    0,    0,    0, -123,
    0,  -65,  -64,    0, -247,    0,  -29,  -28,  -12,  -11,
    0,    0,  -91,    0,    0, -255,  -88,    0,    0,    0,
};
short yyrindex[] = {                                      0,
    0,    0,    0,    0,    0,  -35,    0,    0, -124,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,  -23,  -22,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
};
short yygindex[] = {                                      0,
   38,   -5,    0,   35,    0,    4,    5,    0,    0,
};
#define YYTABLESIZE 140
short yytable[] = {                                      25,
    3,   16,    1,   18,   11,   12,   13,   24,    1,    1,
    5,    6,    6,   22,    4,   19,   23,   20,   15,   33,
   11,   12,   13,   20,   17,   20,   21,   31,   32,   34,
   35,   36,   37,   38,   25,   10,   12,    3,   14,   39,
    0,   40,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    3,    0,   11,   12,   13,   24,
};
short yycheck[] = {                                     123,
  125,    7,  257,    9,  260,  261,  262,  263,  257,  257,
  259,  260,  260,  260,  258,   59,  263,   61,   91,   25,
  260,  261,  262,   59,  259,   61,   59,   93,   93,   59,
   59,   44,   44,  125,  123,   59,   59,    0,    4,   36,
   -1,   37,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  259,   -1,  260,  261,  262,  263,
};
#define YYFINAL 2
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 263
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,"','",0,0,0,0,0,0,0,0,0,0,0,0,0,0,"';'",0,"'='",0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'['",0,"']'",0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'{'",0,"'}'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
"TK_AUTOGEN","TK_DEFINITIONS","TK_END","TK_VAR_NAME","TK_OTHER_NAME",
"TK_STRING","TK_NUMBER",
};
char *yyrule[] = {
"$accept : definitions",
"definitions : identity def_list TK_END",
"definitions : identity TK_END",
"def_list : definition",
"def_list : definition def_list",
"def_list : identity def_list",
"identity : TK_AUTOGEN TK_DEFINITIONS filename ';'",
"definition : value_name ';'",
"definition : value_name '=' text_list ';'",
"definition : value_name '=' block_list ';'",
"text_list : anystring",
"text_list : anystring ',' text_list",
"block_list : def_block",
"block_list : def_block ',' block_list",
"def_block : '{' def_list '}'",
"anystring : filename",
"anystring : TK_NUMBER",
"filename : TK_OTHER_NAME",
"filename : TK_STRING",
"filename : TK_VAR_NAME",
"value_name : TK_VAR_NAME",
"value_name : TK_VAR_NAME '[' TK_NUMBER ']'",
"value_name : TK_VAR_NAME '[' TK_VAR_NAME ']'",
};
#endif
#ifndef YYSTYPE
typedef int YYSTYPE;
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
#if defined(__STDC__)
yyparse(void)
#else
yyparse()
#endif
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 58 "defParse.y"
{ yyval = (YYSTYPE)(rootDefCtx.pDefs = (tDefEntry*)yyvsp[-1]); }
break;
case 2:
#line 60 "defParse.y"
{ yyval = makeEmptyDefs(); }
break;
case 3:
#line 68 "defParse.y"
{ yyval = yyvsp[0]; }
break;
case 4:
#line 69 "defParse.y"
{ yyval = addSibMacro( yyvsp[-1], yyvsp[0] ); }
break;
case 5:
#line 70 "defParse.y"
{ yyval = yyvsp[0]; }
break;
case 6:
#line 74 "defParse.y"
{ yyval = identify( yyvsp[-1] ); }
break;
case 7:
#line 78 "defParse.y"
{ yyval = makeMacro( yyvsp[-1], (YYSTYPE)"", VALTYP_TEXT ); }
break;
case 8:
#line 81 "defParse.y"
{ yyval = makeMacroList( yyvsp[-3], yyvsp[-1], VALTYP_TEXT ); }
break;
case 9:
#line 84 "defParse.y"
{ yyval = makeMacroList( yyvsp[-3], yyvsp[-1], VALTYP_BLOCK ); }
break;
case 10:
#line 87 "defParse.y"
{ yyval = startList( yyvsp[0] ); }
break;
case 11:
#line 88 "defParse.y"
{ yyval = appendList( yyvsp[-2], yyvsp[0] ); }
break;
case 12:
#line 91 "defParse.y"
{ yyval = startList( yyvsp[0] ); }
break;
case 13:
#line 92 "defParse.y"
{ yyval = appendList( yyvsp[-2], yyvsp[0] ); }
break;
case 14:
#line 95 "defParse.y"
{ yyval = yyvsp[-1]; }
break;
case 15:
#line 97 "defParse.y"
{ yyval = yyvsp[0]; }
break;
case 16:
#line 98 "defParse.y"
{ yyval = yyvsp[0]; }
break;
case 17:
#line 100 "defParse.y"
{ yyval = yyvsp[0]; }
break;
case 18:
#line 101 "defParse.y"
{ yyval = yyvsp[0]; }
break;
case 19:
#line 102 "defParse.y"
{ yyval = yyvsp[0]; }
break;
case 20:
#line 105 "defParse.y"
{ yyval = findPlace( (YYSTYPE)yyvsp[0], (YYSTYPE)NULL ); }
break;
case 21:
#line 108 "defParse.y"
{ yyval = findPlace( (YYSTYPE)yyvsp[-3], (YYSTYPE)yyvsp[-1] ); }
break;
case 22:
#line 111 "defParse.y"
{ yyval = findPlace( (YYSTYPE)yyvsp[-3], (YYSTYPE)yyvsp[-1] ); }
break;
#line 428 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
