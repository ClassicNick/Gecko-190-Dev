
#include "config.h"

#ifndef HAVE_STRCSPN
#include <string.h>
#undef strcspn

size_t
strcspn( const char* s, const char* reject )
{
    char   t[256];
    size_t res = 0;

    memset( t+1, 1, sizeof( t )-1);
    t[0] = 0;
    while (*reject)
        t[ (unsigned)(*(reject++)) ] = 0;
    while (t[ *s ] != 0)
        s++, res++;
    return res;
}
#endif /* HAVE_STRCSPN */
