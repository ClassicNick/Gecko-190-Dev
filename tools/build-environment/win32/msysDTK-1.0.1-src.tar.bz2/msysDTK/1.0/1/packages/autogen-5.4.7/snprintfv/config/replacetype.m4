dnl  -*- Mode: M4 -*- 
dnl --------------------------------------------------------------------
dnl replacetype.m4 --- Replace unknown types without needing acconfig.h
dnl
dnl Author:	       Gary V. Vaughan <gvv@techie.com>
dnl Maintainer:	       Gary V. Vaughan <gvv@techie.com>
dnl Created:	       Tue May 16 17:58:30 2000
dnl Last Modified:     Tue May 16 22:26:31 2000
dnl            by:     Gary V. Vaughan <gvv@techie.com>
dnl ---------------------------------------------------------------------
dnl @(#) $Id: replacetype.m4,v 1.1 2000/08/09 01:25:58 gvv Exp $
dnl ---------------------------------------------------------------------
dnl
dnl Code:

# serial 1

dnl SNV_REPLACE_TYPE(TYPE, DEFAULT)
AC_DEFUN(SNV_REPLACE_TYPE,
[AC_REQUIRE([AC_HEADER_STDC])dnl
AC_MSG_CHECKING(for $1)
AC_CACHE_VAL(ac_cv_type_$1,
[AC_EGREP_CPP(dnl
(^|[[^a-zA-Z_0-9]])$1[[^a-zA-Z_0-9]],
[#include <sys/types.h>
#if STDC_HEADERS
#include <stdlib.h>
#include <stddef.h>
#endif], ac_cv_type_$1=yes, ac_cv_type_$1=no)])dnl
AC_MSG_RESULT($ac_cv_type_$1)
if test $ac_cv_type_$1 = no; then
  AC_DEFINE($1, $2, Define to a type used for $1)
fi
])

dnl replacetype.m4 ends here
