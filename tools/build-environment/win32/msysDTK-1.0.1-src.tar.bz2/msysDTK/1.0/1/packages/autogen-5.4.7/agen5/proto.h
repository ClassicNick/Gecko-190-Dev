/* -*- buffer-read-only: t -*- vi: set ro:
 *
 * AutoGen Globally exported prototypes Mon Oct 14 19:25:52 PDT 2002
 */
#ifndef AUTOGEN_PROTOTYPES_H
#define AUTOGEN_PROTOTYPES_H

/* exports from agCgi.c */

void
loadCgi( void );

/* exports from agShell.c */

void
closeServer( void );
int
chainOpen( int       stdinFd,
           tCC**     ppArgs,
           pid_t*    pChild  );
pid_t
openServer( tFdPair* pPair, tCC** ppArgs );
pid_t
openServerFP( tpfPair* pfPair, tCC** ppArgs );
char*
loadData( FILE* fp );
char*
runShell( const char*  pzCmd );

/* exports from agUtils.c */

void
doOptions( int arg_ct, char** arg_vec );
tCC*
getDefine( tCC* pzDefName );
unsigned int
doEscapeChar( tCC* pzIn, char* pRes );
char*
spanQuote( char* pzQte );
tCC*
skipScheme( tCC* pzSrc,  tCC* pzEnd );
tCC*
skipExpression( tCC* pzSrc, size_t len );

/* exports from autogen.c */

void
ag_abend_at( tCC* pzMsg, tCC* pzFile, int line );
void
ag_abend( tCC* pzMsg );

/* exports from defDirect.c */

char*
processDirective( char* pzScan );

/* exports from defFind.c */

int
canonicalizeName( char* pzD, const char* pzS, int srcLen );
tDefEntry*
findDefEntry( char* pzName, ag_bool* pIsIndexed );
tDefEntry**
findEntryList( char* pzName );

/* exports from defLex.c */

int
yylex( void );
void
yyerror( char* s );

/* exports from defLoad.c */

void
readDefines( void );

/* exports from defReduce.c */

YYSTYPE
addSibMacro(
        YYSTYPE  def,
        YYSTYPE  list );
YYSTYPE
makeMacro(
        YYSTYPE    place,
        YYSTYPE    val,
        teValType  type );
YYSTYPE
makeMacroList(
        YYSTYPE    place,
        YYSTYPE    list,
        teValType  type );
YYSTYPE
startList( YYSTYPE entry );
YYSTYPE
appendList(
        YYSTYPE entry,
        YYSTYPE list );
YYSTYPE
findPlace(
        YYSTYPE name,
        YYSTYPE index );
YYSTYPE
makeEmptyDefs( void );
YYSTYPE
identify( YYSTYPE template );

/* exports from expOutput.c */

void
removeWriteAccess( int fd );

/* exports from expPrint.c */

SCM
run_printf( char* pzFmt, int len, SCM alist );

/* exports from funcDef.c */

void
parseMacroArgs( tTemplate* pT, tMacro* pMac );

/* exports from funcEval.c */

char*
resolveSCM( SCM s );
char*
evalExpression( ag_bool* pMustFree );
SCM
eval( const char* pzExpr );

/* exports from loadPseudo.c */

tCC*
doSuffixSpec( tCC* pzData, tCC* pzFileName, int lineNo );
tCC*
loadPseudoMacro( tCC* pzData, tCC* pzFileName );

/* exports from tpLoad.c */

tTemplate*
findTemplate( tCC* pzTemplName );
tSuccess
findFile( tCC* pzFName, char* pzFullName, tCC** papSuffixList );
tTemplate*
templateFixup( tTemplate* pTList, size_t ttlSize );
void
mapDataFile( tCC* pzFileName, tMapInfo* pMapInfo, tCC** papSuffixList );
tTemplate*
loadTemplate( tCC* pzFileName );

/* exports from tpParse.c */

tMacro*
parseTemplate( tMacro* pM, tCC** ppzText );

/* exports from tpProcess.c */

void
generateBlock( tTemplate*   pT,
               tMacro*      pMac,
               tMacro*      pEnd );
void
processTemplate( tTemplate* pTF );
void
closeOutput( ag_bool purge );

#endif /* AUTOGEN_PROTOTYPES_H */
