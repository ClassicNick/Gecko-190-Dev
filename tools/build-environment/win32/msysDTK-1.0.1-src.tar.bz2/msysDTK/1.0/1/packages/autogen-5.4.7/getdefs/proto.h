/* -*- buffer-read-only: t -*- vi: set ro:
 *
 * Getdefs Globally exported prototypes Mon Oct 14 19:25:53 PDT 2002
 */
#ifndef GETDEFS_PROTOTYPES_H
#define GETDEFS_PROTOTYPES_H

/* exports from gdemit.c */

extern char*
emitDefinition( char* pzDef, char* pzOut );

/* exports from gdinit.c */

extern void
fixupSubblockString( char* pz );

extern void
processEmbeddedOptions( char* pzText );

extern void
validateOptions( void );

/* exports from getdefs.c */

extern char*
loadFile( char* pzFname );

#endif /* GETDEFS_PROTOTYPES_H */
