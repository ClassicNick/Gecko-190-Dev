#if defined(USE_GDBM) && !defined(MY_NDBM)

/* #include <gdbm.h> */

#define DBM_INSERT      GDBM_INSERT
#define DBM_REPLACE     GDBM_REPLACE
#define DBM_OPEN        my_gdbm_open
#define DBM_CLOSE       dbm_close
#define DBM_FETCH       dbm_fetch
#define DBM_FIRSTKEY    dbm_firstkey
#define DBM_NEXTKEY     dbm_nextkey
#define DBM_STORE       dbm_store

/* definitions copied from ndbm.h */
typedef struct {int dummy[10];} DBM;
extern GDBM_EXPORT(void,        dbm_close) ();
extern GDBM_EXPORT(datum,       dbm_fetch) ();
extern GDBM_EXPORT(int,         dbm_store) ();
extern GDBM_EXPORT(int,         dbm_delete) ();
extern GDBM_EXPORT(datum,       dbm_firstkey) ();
extern GDBM_EXPORT(datum,       dbm_nextkey) ();

DBM * my_gdbm_open PROTO((char *file, int flags, int mode));
#endif 			/* USE_GDBM && !MY_NDBM */

